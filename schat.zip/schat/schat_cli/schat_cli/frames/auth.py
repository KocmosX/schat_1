import sys
import wx

from panels.login import LoginPanel
from panels.register import RegisterPanel

from frames.chat import ChatFrame

from service.auth_service import AuthService


class AuthFrame(wx.Frame):
    def __init__(self):
        super().__init__(None, title="Авторизация", size=(600, 650))

        self.auth_service = AuthService()

        self.notebook = wx.Notebook(self)

        self.login_panel = LoginPanel(self.notebook)
        self.register_panel = RegisterPanel(self.notebook)

        self.notebook.AddPage(self.login_panel, "Войти")
        self.notebook.AddPage(self.register_panel, "Зарегистрироваться")

        self.Bind(wx.EVT_BUTTON, self.on_login_button,
                  self.login_panel.login_button)
        self.Bind(
            wx.EVT_BUTTON, self.on_register_button, self.register_panel.register_button
        )

        self.Bind(wx.EVT_CLOSE, self.on_close)

        self.__do_layout()
        self.Centre()

    def __do_layout(self):
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.notebook, 1, wx.EXPAND)
        self.SetSizer(sizer)
        self.Layout()

    def on_login_button(self, event):
        login = self.login_panel.login_text.GetValue()
        password = self.login_panel.password_text.GetValue()

        res = self.auth_service.login(login, password)

        if res:
            self.open_chat()
        else:
            print(res.json())
            self.login_panel.error_message.Label = "Неверный логин или пароль"

    def on_register_button(self, event):
        first_name = self.register_panel.first_name_text.GetValue()
        last_name = self.register_panel.second_name_text.GetValue()
        nickname = self.register_panel.nickname_text.GetValue()
        email = self.register_panel.email_text.GetValue()
        password = self.register_panel.password_text.GetValue()
        password_rep = self.register_panel.password_rep_text.GetValue()

        if password != password_rep:
            self.register_panel.error_message.Label = "Пароли не совпадают"

        res = self.auth_service.register(
            first_name, last_name, email, nickname, password
        )

        if res:
            self.open_chat()
        else:
            print(res.json())
            self.register_panel.error_message.Label = "Ошибка с регистрацией"

    def open_chat(self):
        self.chat_frame = ChatFrame(auth_frame=self)
        self.chat_frame.Show()
        self.Hide()

    def on_close(self, event):
        self.Destroy()
        sys.exit()
