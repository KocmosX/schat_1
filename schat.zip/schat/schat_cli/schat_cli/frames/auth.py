import sys                            # Импорт модуля sys для работы с системными параметрами и функциями
import wx                             # Импорт модуля wx - библиотеки для создания графических интерфейсов на основе библиотеки C++

from panels.login import LoginPanel    # Импорт класса LoginPanel из модуля panels.login
from panels.register import RegisterPanel  # Импорт класса RegisterPanel из модуля panels.register

from frames.chat import ChatFrame      # Импорт класса ChatFrame из модуля frames.chat

from service.auth_service import AuthService  # Импорт класса AuthService из модуля service.auth_service


class AuthFrame(wx.Frame):            # Определение класса AuthFrame, который наследуется от класса wx.Frame
    def __init__(self):               # Определение метода __init__, который вызывается при инициализации объекта класса
        super().__init__(None, title="Авторизация", size=(600, 650))   # Вызов конструктора родительского класса wx.Frame

        self.auth_service = AuthService()   # Создание экземпляра класса AuthService и присвоение его атрибуту auth_service

        self.notebook = wx.Notebook(self)    # Создание объекта класса Notebook, представляющего контейнер для вкладок

        self.login_panel = LoginPanel(self.notebook)    # Создание объекта класса LoginPanel и присвоение его атрибуту login_panel
        self.register_panel = RegisterPanel(self.notebook)   # Создание объекта класса RegisterPanel и присвоение его атрибуту register_panel

        self.notebook.AddPage(self.login_panel, "Войти")   # Добавление вкладки с объектом login_panel в объект notebook с названием "Войти"
        self.notebook.AddPage(self.register_panel, "Зарегистрироваться")   # Добавление вкладки с объектом register_panel в объект notebook с названием "Зарегистрироваться"

        self.Bind(wx.EVT_BUTTON, self.on_login_button, self.login_panel.login_button)   # Привязка события wx.EVT_BUTTON к методу on_login_button при нажатии на кнопку login_button
        self.Bind(wx.EVT_BUTTON, self.on_register_button, self.register_panel.register_button)   # Привязка события wx.EVT_BUTTON к методу on_register_button при нажатии на кнопку register_button

        self.Bind(wx.EVT_CLOSE, self.on_close)   # Привязка события wx.EVT_CLOSE к методу on_close при закрытии окна

        self.__do_layout()    # Вызов метода __do_layout для установки макета окна
        self.Centre()         # Центрирование окна на экране

    def __do_layout(self):    # Определение метода __do_layout для установки макета окна
        sizer = wx.BoxSizer(wx.VERTICAL)     # Создание объекта класса BoxSizer с вертикальной ориентацией
        sizer.Add(self.notebook, 1, wx.EXPAND)   # Добавление объекта notebook в объект sizer с коэффициентом растяжения 1 и флагом wx.EXPAND
        self.SetSizer(sizer)    # Установка объекта sizer в качестве менеджера компоновки для окна
        self.Layout()           # Перерасчет размеров и позиции элементов интерфейса

    def on_login_button(self, event):   # Определение метода on_login_button, вызываемого при нажатии кнопки входа
        login = self.login_panel.login_text.GetValue()   # Получение введенного логина из текстового поля login_text
        password = self.login_panel.password_text.GetValue()   # Получение введенного пароля из текстового поля password_text

        res = self.auth_service.login(login, password)    # Вызов метода login класса AuthService и получение результата авторизации

        if res:    # Если результат успешный (True)
            self.open_chat()   # Вызов метода open_chat для открытия окна чата
        else:
            print(res.json())   # Вывод результата в формате JSON
            self.login_panel.error_message.Label = "Неверный логин или пароль"   # Установка текста ошибки в атрибут Label объекта error_message

    def on_register_button(self, event):   # Определение метода on_register_button, вызываемого при нажатии кнопки регистрации
        first_name = self.register_panel.first_name_text.GetValue()   # Получение введенного имени из текстового поля first_name_text
        last_name = self.register_panel.second_name_text.GetValue()   # Получение введенной фамилии из текстового поля second_name_text
        nickname = self.register_panel.nickname_text.GetValue()   # Получение введенного псевдонима из текстового поля nickname_text
        email = self.register_panel.email_text.GetValue()   # Получение введенного адреса электронной почты из текстового поля email_text
        password = self.register_panel.password_text.GetValue()   # Получение введенного пароля из текстового поля password_text
        password_rep = self.register_panel.password_rep_text.GetValue()   # Получение повторно введенного пароля из текстового поля password_rep_text

        if password != password_rep:   # Если пароли не совпадают
            self.register_panel.error_message.Label = "Пароли не совпадают"   # Установка текста ошибки в атрибут Label объекта error_message

        res = self.auth_service.register(first_name, last_name, email, nickname, password)   # Вызов метода register класса AuthService и получение результата регистрации

        if res:   # Если результат успешный (True)
            self.open_chat()   # Вызов метода open_chat для открытия окна чата
        else:
            print(res.json())   # Вывод результата в формате JSON
            self.register_panel.error_message.Label = "Ошибка с регистрацией"   # Установка текста ошибки в атрибут Label объекта error_message

    def open_chat(self):   # Определение метода open_chat для открытия окна чата
        self.chat_frame = ChatFrame(auth_frame=self)   # Создание экземпляра класса ChatFrame с аргументом auth_frame
        self.chat_frame.Show()   # Отображение окна чата
        self.Hide()   # Скрытие окна авторизации

    def on_close(self, event):   # Определение метода on_close, вызываемого при закрытии окна
        self.Destroy()   # Уничтожение окна
        sys.exit()   # Завершение работы приложения