import re
import sys

import wx

from panels.contact_list import ContactListPanel
from panels.search_bar import SearchBarPanel
from panels.contact_info import ContactInfoPanel
from panels.chat import ChatPanel
from panels.send import SendPanel
from service.websocker_service import WebsocketService
from service.user_service import UserService

from service.auth_service import AuthService
from service.dialog_service import DialogService


class ChatFrame(wx.Frame):
    def __init__(self, auth_frame, self_user=None):
        super().__init__(None, title="SChat", size=(1000, 800))

        self.auth_frame = auth_frame

        self.dialog_service = DialogService()
        self.auth_service = AuthService()
        self.user_service = UserService()
        self.websocker_service = WebsocketService()

        self.dialogs = self.dialog_service.get_dialogs().json()

        if not self_user:
            self_user_res = self.user_service.get_self()
            if self_user_res.status_code == 200:
                self.self_user = self_user_res.json()
        else:
            self.self_user = self_user

        self.search_bar = SearchBarPanel(self)
        self.list_box = ContactListPanel(self, self.dialogs, self.self_user)
        self.logout_button = wx.Button(self, label="Выйти")

        self.contact_info = ContactInfoPanel(self)
        self.chat = ChatPanel(self, self.self_user)
        self.send = SendPanel(self, self.websocker_service)

        self.Bind(wx.EVT_BUTTON, self.on_logout_button, self.logout_button)
        self.Bind(wx.EVT_LISTBOX, self.on_select_item, self.list_box.list_ctrl)
        self.Bind(wx.EVT_TEXT, self.on_text_input, self.search_bar.search_bar)
        self.Bind(wx.EVT_CLOSE, self.on_close)

        self.__do_layout()
        self.Centre()

    def __do_layout(self):
        sizer = wx.GridBagSizer(vgap=5, hgap=10)

        sizer.Add(self.search_bar, pos=(0, 0),
                  flag=wx.ALL | wx.EXPAND, border=5)
        sizer.Add(self.contact_info, pos=(0, 1), flag=wx.EXPAND, border=5)
        sizer.Add(self.list_box, pos=(1, 0), flag=wx.ALL | wx.EXPAND, border=5)
        sizer.Add(self.chat, pos=(1, 1), flag=wx.ALL | wx.EXPAND, border=5)
        sizer.Add(
            self.logout_button,
            pos=(2, 0),
            flag=wx.ALL | wx.ALIGN_CENTER,
            border=5,
        )
        sizer.Add(self.send, pos=(2, 1), flag=wx.EXPAND, border=15)

        sizer.AddGrowableCol(0, proportion=1)
        sizer.AddGrowableCol(1, proportion=3)

        sizer.AddGrowableRow(0, proportion=0)
        sizer.AddGrowableRow(1, proportion=9)
        sizer.AddGrowableRow(2, proportion=0)

        self.SetSizer(sizer)
        self.Layout()

    def on_select_item(self, event):
        index = self.list_box.list_ctrl.GetSelection()
        item = self.list_box.get_item(index)

        self.contact_info.set_info(item, self.self_user["id"])
        self.chat.clear_history()
        self.websocker_service.close()

        if "first_user" in item.keys():
            self.chat.load_history(item["id"])
            self.websocker_service.open(
                self.self_user["id"], self.chat.on_message)
            reciver_id = (
                item["first_user"]["id"]
                if item["second_user"]["id"] == self.self_user["id"]
                else item["second_user"]["id"]
            )
            self.send.set_dialog_settings(self.self_user["id"], reciver_id)
        else:
            self.websocker_service.open(
                self.self_user["id"], self.chat.on_message)
            self.send.set_dialog_settings(self.self_user["id"], item["id"])

            for dialog in self.dialogs:
                if item["id"] in [
                    dialog["first_user"]["id"],
                    dialog["second_user"]["id"],
                ]:
                    self.chat.load_history(dialog["id"])
                    break

    def on_logout_button(self, event):
        self.auth_service.logout()
        self.auth_frame.Show()
        self.Hide()

    def on_text_input(self, event):
        entered_text = self.search_bar.search_bar.GetValue()

        if len(entered_text) == 0:
            self.dialogs = self.dialog_service.get_dialogs().json()
            self.list_box.set_items(self.dialogs)
            return

        users = self.user_service.get_users()
        if users.status_code == 200:
            users = users.json()
        else:
            return

        regex_pattern = re.compile(re.escape(entered_text), re.IGNORECASE)

        search_res = []

        for item in users:
            if item["id"] == self.self_user["id"]:
                continue
            if re.search(regex_pattern, item["nickname"]):
                search_res.append(item)
                continue
            if re.search(regex_pattern, item["first_name"]):
                search_res.append(item)
                continue
            if re.search(regex_pattern, item["last_name"]):
                search_res.append(item)
                continue

        self.list_box.set_items(search_res)

    def on_close(self, event):
        self.Destroy()
        sys.exit()
