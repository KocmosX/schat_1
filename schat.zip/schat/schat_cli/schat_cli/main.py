import wx  # Импорт модуля wx для создания графического интерфейса пользователя

from frames.auth import AuthFrame  # Импорт класса AuthFrame из модуля frames.auth
from frames.chat import ChatFrame  # Импорт класса ChatFrame из модуля frames.chat
from service.user_service import UserService  # Импорт класса UserService из модуля service.user_service

class MyApp(wx.App):  # Определение класса MyApp, наследующегося от класса wx.App
    user_service = UserService()  # Создание объекта класса UserService и присвоение его экземпляра переменной user_service

    def OnInit(self):  # Определение метода OnInit без параметров
        res = self.user_service.get_self()  # Вызов метода get_self объекта user_service и присвоение результата переменной res

        frame = AuthFrame()  # Создание экземпляра класса AuthFrame и присвоение его переменной frame
        if res.status_code == 200:  # Проверка, что статусный код ответа равен 200
            frame = ChatFrame(frame, self_user=res.json())  # Создание экземпляра класса ChatFrame, передача ему объекта frame в качестве родительского окна и передача res.json() в качестве значения self_user

        self.SetTopWindow(frame)  # Установка frame в качестве основного окна приложения
        frame.Show()  # Отображение окна frame
        return True  # Возврат True для успешной инициализации приложения

if __name__ == "__main__":  # Проверка, что модуль является главным исполняемым файлом
    app = MyApp(False)  # Создание экземпляра класса MyApp с параметром False
    app.MainLoop()  # Запуск главного цикла приложения