import wx

from frames.auth import AuthFrame
from frames.chat import ChatFrame
from service.user_service import UserService


class MyApp(wx.App):
    user_service = UserService()

    def OnInit(self):
        res = self.user_service.get_self()

        frame = AuthFrame()
        if res.status_code == 200:
            frame = ChatFrame(frame, self_user=res.json())

        self.SetTopWindow(frame)
        frame.Show()
        return True


if __name__ == "__main__":
    app = MyApp(False)
    app.MainLoop()
