from datetime import datetime  # Импорт класса datetime из модуля datetime
import json  # Импорт модуля json
import wx  # Импорт модуля wx для создания графического интерфейса
import wx.html2  # Импорт модуля wx.html2 для работы с компонентом WebView

from panels.message import MessageBox  # Импорт класса MessageBox из модуля panels.message
from service.message_service import MessageService  # Импорт класса MessageService из модуля service.message_service
# Класс ChatPanel, наследующийся от wx.Panel
class ChatPanel(wx.Panel):
    # Конструктор класса ChatPanel
    def __init__(self, parent, self_user):
        super().__init__(parent)

        self.browser = wx.html2.WebView.New(self)  # Создание компонента WebView

        self.base_html = """
<html>
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
</head>
<style>
...

        """
        # Загрузка начальной страницы в WebView
        self.browser.SetPage(self.base_html, "")

        self.message_service = MessageService()  # Создание экземпляра класса MessageService

        self.self_user = self_user  # Сохранение информации о текущем пользователе

        self.scroll_pos = 0  # Позиция скролла

        self.after_paint_timer = wx.Timer(self)  # Создание таймера после отрисовки

        self.__do_layout()  # Вызов приватного метода __do_layout() для размещения компонентов на экране

    # Приватный метод для размещения компонентов на экране
    def __do_layout(self):
        scroll_sizer = wx.BoxSizer(wx.VERTICAL)
        scroll_sizer.Add(self.browser, 1, wx.ALL | wx.EXPAND)
        self.SetSizer(scroll_sizer)

    # Метод для добавления сообщения в окно чата
    def add_message(self, message):
        content, dt, sender_id = message["content"], message["created_at"], message["sender_id"]

        # Проверка формата даты и времени
        if "." in dt:
            input_format = '%Y-%m-%dT%H:%M:%S.%f'
        else:
            input_format = '%Y-%m-%dT%H:%M:%S'
        input_datetime = datetime.strptime(dt, input_format)  # Преобразование строки в объект datetime
        formated_datetime = input_datetime.strftime("%d %B %H:%M")  # Форматирование даты и времени

        isMy = message["sender_id"] == self.self_user["id"]  # Проверка, является ли отправитель текущим пользователем

        owner = "right" if isMy else "left"  # Определение класса CSS в зависимости от отправителя

        # Генерация JavaScript кода для добавления сообщения в WebView
        js_code = f"""
const messageDiv = document.createElement('div');
messageDiv.className = 'message {owner}';

const contentSpan = document.createElement('span');
contentSpan.className = 'content';
contentSpan.textContent = '{content}';

const lineBreak = document.createElement('br');

const timeSpan = document.createElement('span');
timeSpan.className = 'time';
timeSpan.textContent = '{formated_datetime}';

messageDiv.appendChild(contentSpan);
messageDiv.appendChild(lineBreak);
messageDiv.appendChild(timeSpan);

document.body.appendChild(messageDiv);
        """
        self.browser.RunScript(js_code)  # Выполнение JavaScript кода
        self.scroll_down()  # Прокрутка сообщений вниз

    # Метод обратного вызова для обработки входящих сообщений
    def on_message(self, ws, message):
        message = json.loads(message)  # Преобразование JSON строки в объект Python

        wx.CallAfter(self.add_message, message)  # Вызов метода add_message из главного потока

    # Метод для загрузки истории сообщений
    def load_history(self, chad_id):
        pass
        
    # Метод для очистки истории сообщений
    def clear_history(self):
        self.browser.SetPage(self.base_html, "")

    # Метод для прокрутки сообщений вниз
    def scroll_down(self):
        js_code = f"""
        document.body.scrollTop = document.body.scrollHeight;
        """
        self.browser.RunScript(js_code)

        # self.SetScrollPos(wx.VERTICAL, 0)
        # self.GetSizer().Clear(True)

    # def add_message(self, message):
    #     sizer = self.GetSizer()

    #     isMy = message["sender_id"] == self.self_user["id"]

    #     owner = wx.ALIGN_RIGHT if isMy else wx.ALIGN_LEFT

    #     sizer.Add(
    #         MessageBox(
    #             self,
    #             isMy,
    #             message["content"],
    #             message["created_at"],
    #         ),
    #         0,
    #         wx.ALL | owner,
    #         13,
    #     )

    #     sizer.Layout()

    #     self.Layout()

    #     self.after_paint_timer.Start(50, oneShot=True)

    # def on_set_focus(self, event):
    #     self.Scroll(0, self.scroll_pos)

    # def on_scroll(self, event):
    #     self.scroll_pos = self.GetScrollPos(wx.VERTICAL)
    #     event.Skip()

    # def scroll_screen_down(self):
    #     self.Scroll(0, self.GetScrollRange(wx.VERTICAL))

    # def on_timeout(self, event):
    #     self.scroll_screen_down()
    #     event.Skip()
