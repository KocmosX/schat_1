import wx  # Импорт модуля wx для создания графического интерфейса

from service.dialog_service import DialogService  # Импорт класса DialogService из модуля service.dialog_service
from service.message_service import MessageService  # Импорт класса MessageService из модуля service.message_service


class ContactInfoPanel(wx.Panel):  # Определение класса ContactInfoPanel, наследующего от wx.Panel
    def __init__(self, parent):  # Конструктор класса
        super().__init__(parent)  # Вызов конструктора родительского класса

        self.message_service = MessageService()  # Инициализация экземпляра класса MessageService
        self.dialog_service = DialogService()  # Инициализация экземпляра класса DialogService

        self.label = wx.StaticText(self)  # Создание статического текстового элемента
        self.clear_button = wx.Button(self, label="Очистить диалог")  # Создание кнопки с надписью "Очистить диалог"

        self.Bind(wx.EVT_BUTTON, self.clear_history, self.clear_button)  # Привязка события нажатия на кнопку к методу clear_history
        self.__do_layout()  # Вызов приватного метода __do_layout()

    def __do_layout(self):  # Приватный метод для размещения элементов на экране
        sizer = wx.BoxSizer(wx.HORIZONTAL)  # Создание горизонтального контейнера для элементов

        sizer.Add(self.label, 1, wx.ALL | wx.ALIGN_CENTER, 10)  # Добавление статического текста в контейнер
        sizer.Add(self.clear_button, 0, wx.ALL, 10)  # Добавление кнопки в контейнер

        self.SetSizer(sizer)  # Установка контейнера в качестве контейнера компоновки

    def set_info(self, item, self_id):  # Метод для установки информации о контакте
        if "first_user" in item.keys():  # Проверка наличия ключа "first_user" в словаре
            self.selected_chat_id = item["id"]  # Установка идентификатора чата

            if item["first_user"]["id"] != self_id:  # Проверка идентификатора пользователя
                user = item["first_user"]
            else:
                user = item["second_user"]
        else:
            self.selected_chat_id = None  # Сброс идентификатора чата
            self.selected_user_id = item["id"]  # Установка идентификатора пользователя
            user = item

        self.label.Label = f"{user['first_name']} {user['last_name']}"  # Установка текста для label

    def clear_history(self, event):  # Метод для очистки истории диалога
        if self.selected_chat_id:  # Проверка наличия идентификатора чата
            self.message_service.clear_history(self.selected_chat_id)  # Очистка истории сообщений
            self.Parent.chat.clear_history()  # Очистка истории чата в родительском элементе
            dialogs = self.dialog_service.get_dialogs().json()  # Получение списка диалогов
            self.Parent.list_box.set_items(dialogs)  # Обновление списка диалогов в родительском элементе

        elif self.selected_user_id:  # Проверка наличия идентификатора пользователя
            dialogs = self.dialog_service.get_dialogs().json()  # Получение списка диалогов
            for dialog in dialogs:  # Перебор диалогов
                if (dialog["first_user"]["id"] == self.selected_user_id or
                   dialog["second_user"]["id"] == self.selected_user_id):  # Проверка идентификатора пользователя в диалоге
                    self.message_service.clear_history(dialog["id"])  # Очистка истории сообщений
                    self.Parent.chat.clear_history()  # Очистка истории чата в родительском элементе
                    break  # Прерывание цикла