import wx

from service.dialog_service import DialogService
from service.message_service import MessageService


class ContactInfoPanel(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)

        self.message_service = MessageService()
        self.dialog_service = DialogService()

        self.label = wx.StaticText(self)
        self.clear_button = wx.Button(self, label="Очистить диалог")

        self.Bind(wx.EVT_BUTTON, self.clear_history, self.clear_button)
        self.__do_layout()

    def __do_layout(self):
        sizer = wx.BoxSizer(wx.HORIZONTAL)

        sizer.Add(self.label, 1, wx.ALL | wx.ALIGN_CENTER, 10)
        sizer.Add(self.clear_button, 0, wx.ALL, 10)

        self.SetSizer(sizer)

    def set_info(self, item, self_id):
        if "first_user" in item.keys():
            self.selected_chat_id = item["id"]

            if item["first_user"]["id"] != self_id:
                user = item["first_user"]
            else:
                user = item["second_user"]
        else:
            self.selected_chat_id = None
            self.selected_user_id = item["id"]
            user = item

        self.label.Label = f"{user['first_name']} {user['last_name']}"

    def clear_history(self, event):
        if self.selected_chat_id:
            self.message_service.clear_history(self.selected_chat_id)
            self.Parent.chat.clear_history()
            dialogs = self.dialog_service.get_dialogs().json()
            self.Parent.list_box.set_items(dialogs)

        elif self.selected_user_id:
            dialogs = self.dialog_service.get_dialogs().json()
            for dialog in dialogs:
                if (
                    dialog["first_user"]["id"] == self.selected_user_id
                    or dialog["second_user"]["id"] == self.selected_user_id
                ):
                    self.message_service.clear_history(dialog["id"])
                    self.Parent.chat.clear_history()
                    break
