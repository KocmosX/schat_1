import wx


class ContactListPanel(wx.Panel):
    def __init__(self, parent, dialogs, self_user):
        super().__init__(parent)

        self.list_ctrl = wx.ListBox(self, style=wx.LC_REPORT | wx.BORDER_SUNKEN)
        self.self_user = self_user
        self.set_items(dialogs)

        self.__do_layout()

    def __do_layout(self):
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.list_ctrl, 1, wx.ALL | wx.EXPAND)

        self.SetSizer(sizer)

    def add_list_item(self, first_name, last_name, nickname):
        self.list_ctrl.InsertItems([" ".join([first_name, last_name, f"\n@{nickname}"])], 0)

    def get_item(self, index):
        ritems = self.items[:]
        ritems.reverse()
        return ritems[index]

    def set_items(self, items):
        self.items: list = items
        self_id = self.self_user["id"]

        self.list_ctrl.Clear()

        for item in items:
            if "first_user" in item.keys():
                user = item["first_user"] if item["first_user"]["id"] != self_id else item["second_user"]
            elif item["id"] != self_id:
                user = item
            else:
                continue

            self.add_list_item(
                user["first_name"], user["last_name"], user["nickname"]
            )
