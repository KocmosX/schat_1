import wx  # Импорт модуля wx для создания графического интерфейса


class ContactListPanel(wx.Panel):  # Определение класса ContactListPanel, наследующего от wx.Panel
    def __init__(self, parent, dialogs, self_user):  # Конструктор класса
        super().__init__(parent)  # Вызов конструктора родительского класса

        self.list_ctrl = wx.ListBox(self, style=wx.LC_REPORT | wx.BORDER_SUNKEN)  # Создание списка контактов
        self.self_user = self_user  # Установка информации о текущем пользователе
        self.set_items(dialogs)  # Установка элементов списка

        self.__do_layout()  # Вызов приватного метода __do_layout()

    def __do_layout(self):  # Приватный метод для размещения элементов на экране
        sizer = wx.BoxSizer(wx.VERTICAL)  # Создание вертикального контейнера для элементов
        sizer.Add(self.list_ctrl, 1, wx.ALL | wx.EXPAND)  # Добавление списка контактов в контейнер

        self.SetSizer(sizer)  # Установка контейнера в качестве контейнера компоновки

    def add_list_item(self, first_name, last_name, nickname):  # Метод для добавления элемента в список контактов
        self.list_ctrl.InsertItems([" ".join([first_name, last_name, f"\n@{nickname}"])], 0)

    def get_item(self, index):  # Метод для получения элемента списка по индексу
        ritems = self.items[:]
        ritems.reverse()
        return ritems[index]

    def set_items(self, items):  # Метод для установки элементов списка контактов
        self.items: list = items  # Установка списка контактов
        self_id = self.self_user["id"]  # Получение идентификатора текущего пользователя

        self.list_ctrl.Clear()  # Очистка списка контактов

        for item in items:  # Перебор элементов списка
            if "first_user" in item.keys():  # Проверка наличия ключа "first_user" в словаре
                user = item["first_user"] if item["first_user"]["id"] != self_id else item["second_user"]
            elif item["id"] != self_id:  # Проверка идентификатора пользователя
                user = item
            else:
                continue  # Пропуск текущей итерации цикла

            self.add_list_item(  # Добавление элемента контакта в список
                user["first_name"], user["last_name"], user["nickname"]
            )