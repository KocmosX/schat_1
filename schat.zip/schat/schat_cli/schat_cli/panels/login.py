import wx  # Импорт модуля wx

class LoginPanel(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)

        self.login_label = wx.StaticText(self, label="Логин:")  # Создание статического текста "Логин"
        self.login_text = wx.TextCtrl(self)  # Создание текстового поля для ввода логина

        self.password_label = wx.StaticText(self, label="Пароль:")  # Создание статического текста "Пароль"
        self.password_text = wx.TextCtrl(self, style=wx.TE_PASSWORD)  # Создание текстового поля для ввода пароля с скрытым текстом

        self.error_message = wx.StaticText(self)  # Создание статического текста для вывода ошибки (пока пустого)

        self.login_button = wx.Button(self, label="Войти")  # Создание кнопки "Войти"

        self.__do_layout()  # Вызов приватного метода __do_layout()

    def __do_layout(self):
        sizer = wx.BoxSizer(wx.VERTICAL)  # Создание вертикального контейнера для элементов интерфейса
        sizer.Add(self.login_label, 0, wx.ALL, 5)  # Добавление статического текста "Логин" в контейнер
        sizer.Add(self.login_text, 0, wx.EXPAND | wx.ALL, 5)  # Добавление текстового поля для ввода логина в контейнер
        sizer.Add(self.password_label, 0, wx.ALL, 5)  # Добавление статического текста "Пароль" в контейнер
        sizer.Add(self.password_text, 0, wx.EXPAND | wx.ALL, 5)  # Добавление текстового поля для ввода пароля в контейнер
        sizer.Add(self.error_message, 0, wx.ALL, 5)  # Добавление статического текста для вывода ошибки в контейнер
        sizer.Add(self.login_button, 0, wx.ALL | wx.ALIGN_CENTER, 5)  # Добавление кнопки "Войти" в контейнер с выравниванием по центру

        self.SetSizer(sizer)  # Назначение контейнера как основного расположения элементов панели
        sizer.Fit(self)  # Автоматическое подгонка размеров панели под содержимое