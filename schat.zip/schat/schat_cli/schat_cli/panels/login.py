import wx


class LoginPanel(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)

        self.login_label = wx.StaticText(self, label="Логин:")
        self.login_text = wx.TextCtrl(self)

        self.password_label = wx.StaticText(self, label="Пароль:")
        self.password_text = wx.TextCtrl(self, style=wx.TE_PASSWORD)

        self.error_message = wx.StaticText(self)

        self.login_button = wx.Button(self, label="Войти")

        self.__do_layout()

    def __do_layout(self):
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.login_label, 0, wx.ALL, 5)
        sizer.Add(self.login_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.password_label, 0, wx.ALL, 5)
        sizer.Add(self.password_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.error_message, 0, wx.ALL, 5)
        sizer.Add(self.login_button, 0, wx.ALL | wx.ALIGN_CENTER, 5)

        self.SetSizer(sizer)
        sizer.Fit(self)
