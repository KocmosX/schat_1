from datetime import datetime  # Импорт модуля datetime для работы с датой и временем

import wx  # Импорт модуля wx, который предоставляет инструменты для создания графического интерфейса

# Определение класса MessageBox, который наследует от класса wx.Panel
class MessageBox(wx.Panel):
    def __init__(self, parent, owned: bool, label: str, dt: str):
        super().__init__(parent)  # Вызов конструктора родительского класса

        self.sender_color = wx.Colour(31, 196, 237)  # Цвет для отправленных сообщений
        gray = 230  # Значение серого цвета
        self.resived_color = wx.Colour(gray, gray, gray)  # Цвет для полученных сообщений

        # Определение формата даты и времени в зависимости от наличия десятичной части во входной строке
        if "." in dt:
            input_format = '%Y-%m-%dT%H:%M:%S.%f'
        else:
            input_format = '%Y-%m-%dT%H:%M:%S'
            
        input_datetime = datetime.strptime(dt, input_format)  # Преобразование входной строки в объект datetime
        formated_datetime = input_datetime.strftime("%d %B %H:%M")  # Форматирование даты и времени в нужный вид

        # Создание текстовых полей для отображения содержимого сообщения и даты/времени
        self.content = wx.StaticText(self, label=label)
        self.datetime = wx.StaticText(self, label=formated_datetime)
        self.owned = owned

        self.datetime.SetFont(wx.SMALL_FONT)  # Установка шрифта для поля с датой/временем
        self.Bind(wx.EVT_PAINT, self.on_paint)  # Привязка события on_paint к отрисовке виджета

        self.__do_layout()  # Вызов внутреннего метода для настройки разметки виджета

    def __do_layout(self):
        self.SetBackgroundStyle(wx.BG_STYLE_CUSTOM)  # Установка пользовательского фона

        sizer = wx.BoxSizer(wx.VERTICAL)  # Создание вертикального контейнера для компонентов

        side = wx.ALIGN_RIGHT if self.owned else wx.ALIGN_LEFT  # Выравнивание компонентов в зависимости от типа сообщения
        sizer.Add(self.content, 1, wx.ALL | side, 10)  # Добавление текстового поля содержимого в контейнер с отступами
        sizer.Add(self.datetime, 1, wx.ALL | side, 10)  # Добавление текстового поля с датой/временем в контейнер с отступами

        self.SetSizer(sizer)  # Установка контейнера в качестве разметки для виджета

        if self.owned:
            self.SetBackgroundColour(self.sender_color)  # Установка цвета фона для отправленных сообщений
        else:
            self.SetBackgroundColour(self.resived_color)  # Установка цвета фона для полученных сообщений

    def on_paint(self, event):
        dc = wx.AutoBufferedPaintDC(self)  # Создание контекста рисования для виджета
        gc = wx.GraphicsContext.Create(dc)  # Создание объекта графического контекста

        width, height = self.GetSize()  # Получение размеров виджета
        corner_radius = 10  # Радиус закругления углов

        if self.owned:
            gc.SetBrush(wx.Brush(self.sender_color))  # Установка кисти для рисования прямоугольника отправленного сообщения
        else:
            gc.SetBrush(wx.Brush(self.resived_color))  # Установка кисти для рисования прямоугольника полученного сообщения

        gc.SetPen(wx.Pen(wx.Colour(0, 0, 0, 0), width=0))  # Установка прозрачного пера для рисования границы прямоугольника

        gc.DrawRoundedRectangle(0, 0, width, height, corner_radius)  # Отрисовка закругленного прямоугольника

        event.Skip()  # Пропуск события для дальнейшей обработки