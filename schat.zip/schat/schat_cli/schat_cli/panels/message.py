from datetime import datetime

import wx


class MessageBox(wx.Panel):
    def __init__(self, parent, owned: bool, label: str, dt: str):
        super().__init__(parent)

        self.sender_color = wx.Colour(31, 196, 237)
        gray = 230
        self.resived_color = wx.Colour(gray, gray, gray)

        if "." in dt:
            input_format = '%Y-%m-%dT%H:%M:%S.%f'
        else:
            input_format = '%Y-%m-%dT%H:%M:%S'
        input_datetime = datetime.strptime(dt, input_format)
        formated_datetime = input_datetime.strftime("%d %B %H:%M")

        self.content = wx.StaticText(self, label=label)
        self.datetime = wx.StaticText(self, label=formated_datetime)
        self.owned = owned

        self.datetime.SetFont(wx.SMALL_FONT)
        self.Bind(wx.EVT_PAINT, self.on_paint)

        self.__do_layout()

    def __do_layout(self):
        self.SetBackgroundStyle(wx.BG_STYLE_CUSTOM)

        sizer = wx.BoxSizer(wx.VERTICAL)

        side = wx.ALIGN_RIGHT if self.owned else wx.ALIGN_LEFT
        sizer.Add(self.content, 1, wx.ALL | side, 10)
        sizer.Add(self.datetime, 1, wx.ALL | side, 10)

        self.SetSizer(sizer)

        if self.owned:
            self.SetBackgroundColour(self.sender_color)
        else:
            self.SetBackgroundColour(self.resived_color)

    def on_paint(self, event):
        dc = wx.AutoBufferedPaintDC(self)
        gc = wx.GraphicsContext.Create(dc)

        width, height = self.GetSize()
        corner_radius = 10  # Радиус закругления углов

        if self.owned:
            gc.SetBrush(wx.Brush(self.sender_color))
        else:
            gc.SetBrush(wx.Brush(self.resived_color))

        gc.SetPen(wx.Pen(wx.Colour(0, 0, 0, 0), width=0))

        gc.DrawRoundedRectangle(0, 0, width, height, corner_radius)

        event.Skip()
