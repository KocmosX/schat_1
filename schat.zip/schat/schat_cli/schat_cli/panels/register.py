import wx  # импортируем библиотеку wx

class RegisterPanel(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)  # вызываем конструктор базового класса

        self.first_name_label = wx.StaticText(self, label="Имя:")  # создаем статический текст "Имя:"
        self.first_name_text = wx.TextCtrl(self)  # создаем текстовое поле для ввода имени

        self.second_name_label = wx.StaticText(self, label="Фамилия:")  # создаем статический текст "Фамилия:"
        self.second_name_text = wx.TextCtrl(self)  # создаем текстовое поле для ввода фамилии

        self.nickname_label = wx.StaticText(self, label="Имя пользователя:")  # создаем статический текст "Имя пользователя:"
        self.nickname_text = wx.TextCtrl(self)  # создаем текстовое поле для ввода имени пользователя

        self.email_label = wx.StaticText(self, label="Почта:")  # создаем статический текст "Почта:"
        self.email_text = wx.TextCtrl(self)  # создаем текстовое поле для ввода почты

        self.password_label = wx.StaticText(self, label="Пароль:")  # создаем статический текст "Пароль:"
        self.password_text = wx.TextCtrl(self, style=wx.TE_PASSWORD)  # создаем текстовое поле для ввода пароля с опцией скрытия символов

        self.password_rep_label = wx.StaticText(self, label="Повторите пароль:")  # создаем статический текст "Повторите пароль:"
        self.password_rep_text = wx.TextCtrl(self, style=wx.TE_PASSWORD)  # создаем текстовое поле для повторного ввода пароля с опцией скрытия символов

        self.error_message = wx.StaticText(self)  # создаем статический текст для отображения ошибок

        self.register_button = wx.Button(self, label="Зарегистрироваться")  # создаем кнопку "Зарегистрироваться"

        self.__do_layout()  # вызываем метод для установки макета виджетов на панели

    def __do_layout(self):
        sizer = wx.BoxSizer(wx.VERTICAL)  # создаем вертикальный контейнер для размещения виджетов

        # добавляем виджеты в контейнер с указанием параметров размещения
        sizer.Add(self.first_name_label, 0, wx.ALL, 5)
        sizer.Add(self.first_name_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.second_name_label, 0, wx.ALL, 5)
        sizer.Add(self.second_name_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.nickname_label, 0, wx.ALL, 5)
        sizer.Add(self.nickname_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.email_label, 0, wx.ALL, 5)
        sizer.Add(self.email_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.password_label, 0, wx.ALL, 5)
        sizer.Add(self.password_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.password_rep_label, 0, wx.ALL, 5)
        sizer.Add(self.password_rep_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.error_message, 0, wx.ALL, 5)
        sizer.Add(self.register_button, 0, wx.ALL | wx.ALIGN_CENTER, 5)

        self.SetSizer(sizer)  # устанавливаем контейнер с виджетами в качестве основного макета панели
        sizer.Fit(self)