import wx

# Создаем класс панели для отправки сообщений
class SendPanel(wx.Panel):
    def __init__(self, parent, ws):
        super().__init__(parent)

        # Создаем текстовое поле для ввода сообщений
        self.input_bar = wx.TextCtrl(self, style=wx.TE_PROCESS_ENTER)
        # Создаем кнопку "Отправить"
        self.send_button = wx.Button(self, label="Отправить")
        # Сохраняем ссылку на WebSocket соединение
        self.ws = ws

        # Привязываем обработчик события нажатия на кнопку "Отправить"
        self.Bind(wx.EVT_BUTTON, self.on_send, self.send_button)
        # Привязываем обработчик события нажатия Enter в текстовом поле
        self.Bind(wx.EVT_TEXT_ENTER, self.on_send, self.input_bar)

        # Выполняем расположение элементов на панели
        self.__do_layout()

    def __do_layout(self):
        # Создаем горизонтальный контейнер для элементов
        sizer = wx.BoxSizer(wx.HORIZONTAL)
        # Добавляем текстовое поле в контейнер с растяжкой на все доступное пространство, с отступами 10 пикселей со всех сторон
        sizer.Add(self.input_bar, 1, wx.ALL, 10)
        # Добавляем кнопку "Отправить" в контейнер с отступами 10 пикселей со всех сторон
        sizer.Add(self.send_button, 0, wx.ALL, 10)

        # Устанавливаем контейнер как раскладку для панели
        self.SetSizer(sizer)

    def set_dialog_settings(self, sender_id, reciver_id):
        # Устанавливаем идентификатор отправителя и получателя для диалога
        self.sender_id = sender_id
        self.reciver_id = reciver_id

    def on_send(self, event):
        # Получаем текст сообщения из текстового поля
        message = self.input_bar.GetValue().strip()

        # Если сообщение пустое, прекращаем выполнение функции
        if len(message) == 0:
            return

        # Отправляем сообщение через WebSocket соединение
        self.ws.send(self.sender_id, self.reciver_id, message)
        # Очищаем текстовое поле после отправки сообщения
        self.input_bar.SetValue("")