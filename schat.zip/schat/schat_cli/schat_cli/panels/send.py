import wx


class SendPanel(wx.Panel):
    def __init__(self, parent, ws):
        super().__init__(parent)

        self.input_bar = wx.TextCtrl(self, style=wx.TE_PROCESS_ENTER)
        self.send_button = wx.Button(self, label="Отправить")
        self.ws = ws

        self.Bind(wx.EVT_BUTTON, self.on_send, self.send_button)
        self.Bind(wx.EVT_TEXT_ENTER, self.on_send, self.input_bar)

        self.__do_layout()

    def __do_layout(self):
        sizer = wx.BoxSizer(wx.HORIZONTAL)
        sizer.Add(self.input_bar, 1, wx.ALL, 10)
        sizer.Add(self.send_button, 0, wx.ALL, 10)

        self.SetSizer(sizer)

    def set_dialog_settings(self, sender_id, reciver_id):
        self.sender_id = sender_id
        self.reciver_id = reciver_id

    def on_send(self, event):
        message = self.input_bar.GetValue().strip()

        if len(message) == 0:
            return

        self.ws.send(self.sender_id, self.reciver_id, message)
        self.input_bar.SetValue("")
