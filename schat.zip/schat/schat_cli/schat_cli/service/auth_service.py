from service.requests_service import RequestService
from service.token_service import TokenService
import requests


class AuthService:
    requests_service = RequestService()
    token_service = TokenService()

    def login(self, login, password):
        res = requests.post(
            self.requests_service.baseurl + "/api/auth/local/signin",
            json={"login": login, "password": password},
        )

        if res.status_code == 200:
            access, refresh = res.json().values()
            self.token_service.set_access_token(access)
            self.token_service.set_refresh_token(refresh)

            return res 

        return res

    def register(self, first_name, last_name, email, nickname, password):
        res = requests.post(
            self.requests_service.baseurl + "/api/auth/local/signup",
            json={
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
                "nickname": nickname,
                "password": password,
            },
        )

        if res.status_code == 201:
            access, refresh = res.json().values()
            self.token_service.set_access_token(access)
            self.token_service.set_refresh_token(refresh)

            return res 

        return res

    def logout(self):
        self.requests_service.make_request("POST", "/api/auth/logout")
        self.token_service.set_access_token("")
        self.token_service.set_refresh_token("")
