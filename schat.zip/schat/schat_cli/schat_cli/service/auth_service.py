from service.requests_service import RequestService  # импорт класса RequestService из модуля requests_service
from service.token_service import TokenService  # импорт класса TokenService из модуля token_service
import requests  # импорт модуля requests

class AuthService:
    requests_service = RequestService()  # создание экземпляра класса RequestService и сохранение в атрибуте requests_service
    token_service = TokenService()  # создание экземпляра класса TokenService и сохранение в атрибуте token_service

    def login(self, login, password):
        res = requests.post(
            self.requests_service.baseurl + "/api/auth/local/signin",  # составление URL для запроса в соответствии с baseurl из requests_service
            json={"login": login, "password": password},  # передача значений login и password в виде JSON в теле запроса
        )

        if res.status_code == 200:  # проверка статусного кода ответа
            access, refresh = res.json().values()  # получение значений access и refresh из JSON тела ответа
            self.token_service.set_access_token(access)  # сохранение access в access_token через token_service
            self.token_service.set_refresh_token(refresh)  # сохранение refresh в refresh_token через token_service

            return res  # возврат ответа

        return res  # возврат ответа

    def register(self, first_name, last_name, email, nickname, password):
        res = requests.post(
            self.requests_service.baseurl + "/api/auth/local/signup",  # составление URL для запроса в соответствии с baseurl из requests_service
            json={
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
                "nickname": nickname,
                "password": password,
            },  # передача значений first_name, last_name, email, nickname и password в виде JSON в теле запроса
        )

        if res.status_code == 201:  # проверка статусного кода ответа
            access, refresh = res.json().values()  # получение значений access и refresh из JSON тела ответа
            self.token_service.set_access_token(access)  # сохранение access в access_token через token_service
            self.token_service.set_refresh_token(refresh)  # сохранение refresh в refresh_token через token_service

            return res  # возврат ответа

        return res  # возврат ответа

    def logout(self):
        self.requests_service.make_request("POST", "/api/auth/logout")  # выполнение POST-запроса с указанным методом и URL
        self.token_service.set_access_token("")  # установка пустого значения для access_token через token_service
        self.token_service.set_refresh_token("")  # установка пустого значения для refresh_token через token_service