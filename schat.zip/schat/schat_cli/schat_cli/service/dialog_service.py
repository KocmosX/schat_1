from service.requests_service import RequestService


class DialogService:
    requests_service = RequestService()

    def get_dialogs(self):
        return self.requests_service.make_request("GET", "/api/dialog/")

    def get_dialog(self, id):
        return self.requests_service.make_request("GET", "/api/dialog/" + str(id))

