from service.requests_service import RequestService  # Импорт класса RequestService из модуля requests_service

class DialogService:  # Определение класса DialogService
    requests_service = RequestService()  # Создание экземпляра класса RequestService

    def get_dialogs(self):  # Определение метода get_dialogs
        return self.requests_service.make_request("GET", "/api/dialog/")  # Вызов метода make_request класса RequestService с параметрами "GET" и "/api/dialog/"

    def get_dialog(self, id):  # Определение метода get_dialog с параметром id
        return self.requests_service.make_request("GET", "/api/dialog/" + str(id))  # Вызов метода make_request класса RequestService с параметрами "GET" и "/api/dialog/" + str(id)