from service.requests_service import RequestService  # Импорт класса RequestService из модуля requests_service

class MessageService:  # Определение класса MessageService
    request_service = RequestService()  # Создание экземпляра класса RequestService

    def get_history(self, chat_id):  # Определение метода get_history с параметром chat_id
        return self.request_service.make_request("GET", f"/api/message/{chat_id}")  # Вызов метода make_request класса RequestService с параметрами "GET" и f"/api/message/{chat_id}"

    def clear_history(self, chat_id):  # Определение метода clear_history с параметром chat_id
        return self.request_service.make_request("DELETE", f"/api/message/{chat_id}")  # Вызов метода make_request класса RequestService с параметрами "DELETE" и f"/api/message/{chat_id}"