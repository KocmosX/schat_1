import requests  # Импорт модуля requests

from service.token_service import TokenService  # Импорт класса TokenService из модуля token_service
from config import host  # Импорт переменной host из модуля config

class RequestService:  # Определение класса RequestService
    def __init__(self):  # Определение конструктора класса
        self.session = requests.Session()  # Создание сессии для отправки HTTP-запросов
        self.baseurl = f"http://{host}"  # Формирование базового URL-адреса, используя переменную host из модуля config
        self.token_service = TokenService()  # Создание экземпляра класса TokenService

    def make_request(self, method: str, url: str, data=None):  # Определение метода make_request с параметрами method (тип str), url (тип str) и data (тип None по умолчанию)
        response = self.session.request(  # Отправка HTTP-запроса с использованием сессии
            method,  # Метод HTTP-запроса (GET, POST, PUT, DELETE и т. д.)
            self.baseurl + url,  # URL-адрес запроса, составленный из базового URL-адреса и переданного URL-адреса
            json=data,  # JSON-данные запроса (если есть)
            headers={  # Заголовки запроса
                "Authorization": f"Bearer {self.token_service.get_access_token()}"  # Заголовок Authorization с токеном доступа, полученным от экземпляра класса TokenService
            },
        )

        if response.status_code == 401 or response.status_code == 403:  # Если код ответа равен 401 (Unauthorized) или 403 (Forbidden)
            new_jwt = self.session.post(  # Отправка POST-запроса для обновления JWT-токенов
                self.baseurl + "/api/auth/refresh",  # URL-адрес для обновления токенов
                headers={  # Заголовки запроса
                    "Authorization": f"Bearer {self.token_service.get_refresh_token()}"  # Заголовок Authorization с токеном обновления, полученным от экземпляра класса TokenService
                },
            )

            if new_jwt.status_code != 403 and new_jwt.status_code != 401 and new_jwt.status_code != 404:  # Если код ответа нового JWT не равен 401 (Unauthorized), 403 (Forbidden) или 404 (Not Found)
                access = new_jwt.json()["access_token"]  # Получение токена доступа из ответа в формате JSON
                refresh = new_jwt.json()["refresh_token"]  # Получение токена обновления из ответа в формате JSON

                self.token_service.set_access_token(access)  # Установка нового токена доступа в экземпляре класса TokenService
                self.token_service.set_refresh_token(refresh)  # Установка нового токена обновления в экземпляре класса TokenService

                return self.session.request(  # Повторная отправка исходного HTTP-запроса с обновленным токеном доступа
                    method,
                    self.baseurl + url,
                    json=data,
                    headers={"Authorization": f"Bearer {access}"},
                )

            return new_jwt  # Возврат ответа нового JWT

        return response  # Возврат исходного ответа

if __name__ == "__main__":  # Если скрипт запущен как основной
    interceptor = RequestService()  # Создание экземпляра класса RequestService
    response = interceptor.make_request("GET", "/api/user")  # Отправка GET-запроса на "/api/user" с помощью экземпляра класса RequestService
    print(response.json())  # Вывод ответа в формате JSON