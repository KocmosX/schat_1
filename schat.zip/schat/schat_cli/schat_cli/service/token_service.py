import keyring  # Импорт модуля keyring

class TokenService:  # Определение класса TokenService
    refresh = "refresh"  # Константа refresh, используется в качестве ключа для хранения токена обновления
    access = "access"  # Константа access, используется в качестве ключа для хранения токена доступа

    def get_access_token(self) -> str:  # Определение метода get_access_token без параметров, возвращающего строку
        return keyring.get_password("schat", self.access) or ""  # Получение токена доступа из хранилища keyring или пустой строки, если токен отсутствует

    def get_refresh_token(self) -> str:  # Определение метода get_refresh_token без параметров, возвращающего строку
        return keyring.get_password("schat", self.refresh) or ""  # Получение токена обновления из хранилища keyring или пустой строки, если токен отсутствует

    def set_access_token(self, token: str):  # Определение метода set_access_token с параметром token типа str
        keyring.set_password("schat", self.access, token)  # Установка значения токена доступа в хранилище keyring

    def set_refresh_token(self, token: str):  # Определение метода set_refresh_token с параметром token типа str
        keyring.set_password("schat", self.refresh, token)  # Установка значения токена обновления в хранилище keyring