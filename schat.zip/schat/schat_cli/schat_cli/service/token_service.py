import keyring


class TokenService:
    refresh = "refresh"
    access = "access"

    def get_access_token(self) -> str:
        return keyring.get_password("schat", self.access) or ""

    def get_refresh_token(self) -> str:
        return keyring.get_password("schat", self.refresh) or ""

    def set_access_token(self, token: str):
        keyring.set_password("schat", self.access, token)

    def set_refresh_token(self, token: str):
        keyring.set_password("schat", self.refresh, token)
