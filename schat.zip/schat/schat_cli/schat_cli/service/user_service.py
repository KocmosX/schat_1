from service.requests_service import RequestService  # Импорт класса RequestService из модуля service.requests_service

class UserService:  # Определение класса UserService
    requests_service = RequestService()  # Создание экземпляра класса RequestService и присвоение его объекта переменной requests_service

    def get_users(self):  # Определение метода get_users без параметров
        return self.requests_service.make_request("GET", "/api/user/")  # Выполнение HTTP-запроса GET на эндпоинт /api/user/

    def get_self(self):  # Определение метода get_self без параметров
        return self.requests_service.make_request("GET", "/api/user/self")  # Выполнение HTTP-запроса GET на эндпоинт /api/user/self