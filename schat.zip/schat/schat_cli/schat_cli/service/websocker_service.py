import json  # Импорт модуля json для работы с JSON
import websocket  # Импорт модуля websocket для работы с веб-сокетами
import threading  # Импорт модуля threading для создания потоков
from functools import partial  # Импорт функции partial из модуля functools
from config import host  # Импорт переменной host из модуля config

websocket.enableTrace(False)  # Отключение вывода отладочной информации модуля websocket

class WebsocketService:  # Определение класса WebsocketService
    def __init__(self):  # Определение конструктора класса
        # websocket.enableTrace(False)
        self.ws_url = f"ws://{host}/api/message/ws/"  # Формирование URL для подключения к веб-сокету, используя переменную host из модуля config
        self.ws = None  # Инициализация переменной ws значением None

    def send(self, sender_id, reciver_id, content):  # Определение метода send с параметрами sender_id, reciver_id и content
        message_data = {  # Создание словаря message_data
            "sender_id": sender_id,
            "reciver_id": reciver_id,
            "content": content,
        }

        json_message = json.dumps(message_data)  # Преобразование словаря message_data в строку JSON

        self.ws.send(json_message)  # Отправка строки JSON по веб-сокету

    def close(self):  # Определение метода close без параметров
        if self.ws:  # Проверка, что переменная ws не равна None
            self.ws.close()  # Закрытие соединения по веб-сокету
            self.ws = None  # Присвоение переменной ws значения None

    # just example
    def on_message(self, ws, message):  # Определение метода on_message с параметрами ws и message
        json_message = json.loads(message)  # Преобразование строки JSON в словарь

    def open(self, sender_id, on_message):  # Определение метода open с параметрами sender_id и on_message
        self.ws = websocket.WebSocketApp(  # Создание экземпляра класса WebSocketApp из модуля websocket
            self.ws_url + str(sender_id),  # Формирование URL для подключения к веб-сокету, добавляя sender_id к ws_url
            on_message=on_message,  # Передача функции on_message в качестве обработчика входящих сообщений
        )

        ws_thread = threading.Thread(target=self.ws.run_forever)  # Создание потока, в котором будет выполняться метод run_forever экземпляра WebSocketApp
        ws_thread.daemon = True  # Установка флага daemon для потока
        ws_thread.start()  # Запуск потока