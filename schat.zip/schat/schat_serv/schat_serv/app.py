import os
from dotenv import load_dotenv
from cryptography.fernet import Fernet

import uvicorn
from fastapi import FastAPI

import models
from routers import auth, user, dialog, message

# Загрузить переменные окружения из файла .env
load_dotenv()

# Переменные из файла .env
title = "schat" # Заголовок приложения
port = int(os.getenv("PORT") or 3000) # Порт, используемый сервером (берется из переменной окружения PORT, если она задана, иначе используется 3000)
host = os.getenv("HOST") or "localhost" # Хост, используемый сервером (берется из переменной окружения HOST, если она задана, иначе используется "localhost")

# Если переменная окружения CIPHER_KEY не задана, генерировать новый шифровальный ключ и сохранить его в файл .env
if not os.getenv("CIPHER_KEY"):
    key = Fernet.generate_key() # Генерировать новый шифровальный ключ
    with open(".env", "a") as env_file:
        env_file.write(f"CIPHER_KEY={key.decode()}") # Сохранить ключ в файл .env

# Инициализация объекта FastAPI с заданными параметрами
app = FastAPI(
    title=title, # Заголовок приложения
    docs_url="/api/docs", # URL для документации API
    openapi_url="/api/openapi.json", # URL для открытой спецификации OpenAPI
    version="1.0" # Версия приложения
)

# Подключение всех роутеров (маршрутов) к основному приложению
app.include_router(auth.auth_route, prefix="/api/auth", tags=["Auth"])
app.include_router(user.user_route, prefix="/api/user", tags=["User"])
app.include_router(dialog.dialog_route, prefix="/api/dialog", tags=["Dialog"])
app.include_router(message.message_router, prefix="/api/message", tags=["Message"])

# Корневой эндпоинт
@app.get("/")
async def root():
    return f"API server or {title}"

# Если файл app.py запускается напрямую (а не импортируется)
if __name__ == "__main__":
    models.database_create() # Создание базы данных

    # Запуск сервера с параметрами из переменных
    uvicorn.run("app:app", port=port, host=host, reload=True)