from models.database import database #Здесь мы импортируем базу данных, которая будет использоваться в нашем проекте.
from models.user import User #Здесь мы импортируем модель User, которая будет представлять пользователя в нашей базе данных.
from models.dialog import Dialog #Здесь мы импортируем модель Dialog, которая будет представлять диалог (чат) в нашей базе данных.
from models.dialog_message import DialogMessage #Здесь мы импортируем модель DialogMessage, которая будет представлять сообщение внутри диалога в нашей базе данных.
from models.message import Message #Здесь мы импортируем модель Message, которая будет представлять сообщение отдельно от диалога в нашей базе данных.


def database_create(): #Здесь мы объявляем функцию с именем "database_create".
    with database: #Здесь мы используем контекстный менеджер "with" для открытия базы данных.
        database.create_tables([User, Message, Dialog, DialogMessage]) #Здесь мы вызываем метод "create_tables" из базы данных, передавая ему список моделей (User, Message, Dialog, DialogMessage). Этот метод создаст таблицы в базе данных для каждой модели, если они еще не существуют.
