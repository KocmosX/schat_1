from peewee import ForeignKeyField  # Импорт ForeignKeyField из модуля peewee
from models.database import BaseModel  # Импорт базовой модели BaseModel из модуля models.database
from models.dialog import Dialog  # Импорт модели Dialog из модуля models.dialog
from models.message import Message  # Импорт модели Message из модуля models.message

class DialogMessage(BaseModel):  # Определение нового класса DialogMessage, наследующего BaseModel
    dialog = ForeignKeyField(Dialog)  # Определение поля 'dialog' в модели DialogMessage типа ForeignKeyField, связанного с моделью Dialog
    message = ForeignKeyField(Message)  # Определение поля 'message' в модели DialogMessage типа ForeignKeyField, связанного с моделью Message