from peewee import ForeignKeyField
from models.database import BaseModel
from models.dialog import Dialog
from models.message import Message


class DialogMessage(BaseModel):
    dialog = ForeignKeyField(Dialog)  # type: Dialog
    message = ForeignKeyField(Message)  # type: Message
