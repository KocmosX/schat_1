from peewee import DateTimeField, ForeignKeyField, TextField # импорт 
from models.database import BaseModel
from models.user import User
from datetime import datetime

# Определение модели сообщения

class Message(BaseModel):
    sender = ForeignKeyField(User)  # Определение поля-внешнего ключа "sender", которое ссылается на модель "User"
    created_at = DateTimeField(null=False)  # Определение поля "created_at" со значением времени и даты создания сообщения; null=False означает, что поле не может быть пустым
    content = TextField(null=False)  # Определение поля "content" для хранения текстового содержимого сообщения; null=False означает, что поле не может быть пустым