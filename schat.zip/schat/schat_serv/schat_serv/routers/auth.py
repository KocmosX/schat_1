from fastapi import APIRouter, Depends, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from services.auth_service import AuthService
from models import database, user
from schemas import token, user

auth_route = APIRouter()
security = HTTPBearer()
auth_service = AuthService()


def get_db():
    try:
        database.connect()
    finally:
        if not database.is_closed():
            database.close()


@auth_route.post(
    "/local/signup",
    status_code=status.HTTP_201_CREATED,
    response_model=token.Tokens,
    dependencies=[Depends(get_db)],
)
async def signup(dto: user.UserSignUp) -> token.Tokens:
    return auth_service.signup(dto)


@auth_route.post(
    "/local/signin",
    status_code=status.HTTP_200_OK,
    response_model=token.Tokens,
    dependencies=[Depends(get_db)],
)
async def signin(dto: user.UserSignIn) -> token.Tokens:
    return auth_service.signin(dto)


@auth_route.post(
    "/refresh",
    status_code=status.HTTP_200_OK,
    response_model=token.Tokens,
    dependencies=[Depends(get_db)],
)
async def refresh(
    credentials: HTTPAuthorizationCredentials = Security(security),
) -> token.Tokens:
    return auth_service.refresh_tokens(credentials.credentials)


@auth_route.post(
    "/logout",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(get_db)],
)
async def logout(
    credentials: HTTPAuthorizationCredentials = Security(security),
):
    auth_service.logout(credentials.credentials)
