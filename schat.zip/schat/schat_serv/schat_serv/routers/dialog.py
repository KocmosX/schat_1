from fastapi import APIRouter, Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from services.dialog_service import DialogService
from schemas.dialog import DialogOut
from services.auth_service import AuthService
from models import database

# Создание экземпляра маршрутизатора API
dialog_route = APIRouter()

# Создание экземпляра класса HTTPBearer для обеспечения аутентификации с использованием Bearer-токена
security = HTTPBearer()

# Создание экземпляра класса AuthService для работы с аутентификацией
auth_service = AuthService()

# Создание экземпляра класса DialogService для работы с диалогами
dialog_service = DialogService()

# Функция зависимости для подключения к базе данных
def get_db():
    try:
        # Установка соединения с базой данных
        database.connect()
    finally:
        if not database.is_closed():
            # Закрытие соединения с базой данных, если оно было открыто
            database.close()

# Маршрут для получения информации о конкретном диалоге
@dialog_route.get(
    "/{id}",
    status_code=status.HTTP_200_OK,
    response_model=DialogOut | None,
    dependencies=[Depends(get_db)],
)
async def get_dialog(
    id: str,
    cred: HTTPAuthorizationCredentials = Security(security),
) -> DialogOut | None:
    try:
        dialog_id = int(id)
        if auth_service.decode_token(cred.credentials):
            # Вызов метода get_dialog() из DialogService для получения информации о диалоге
            return dialog_service.get_dialog(dialog_id)
        return None
    except ValueError:
        # Генерация исключения HTTPException в случае некорректного значения идентификатора диалога
        raise HTTPException(400, "ID param it's not number")

# Маршрут для получения списка диалогов пользователя
@dialog_route.get(
    "/",
    status_code=status.HTTP_200_OK,
    response_model=list[DialogOut] | None,
    dependencies=[Depends(get_db)],
)
async def get_dialogs(
    cred: HTTPAuthorizationCredentials = Security(security),
) -> list[DialogOut] | None:
    try:
        user_id = int(auth_service.decode_token(cred.credentials)["id"])
        if auth_service.decode_token(cred.credentials):
            # Вызов метода get_dialogs() из DialogService для получения списка диалогов пользователя
            return dialog_service.get_dialogs(user_id)
        return None
    except ValueError:
        # Генерация исключения HTTPException в случае некорректного значения идентификатора пользователя
        raise HTTPException(400, "ID param it's not number")