from fastapi import APIRouter, Depends, HTTPException, Security, WebSocket, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from schemas.message import MessageOut
from services.message_service import MessageService
from services.auth_service import AuthService
from models import database

message_router = APIRouter()
security = HTTPBearer()
auth_service = AuthService()
message_service = MessageService()


def get_db():
    try:
        database.connect()
    finally:
        if not database.is_closed():
            database.close()


@message_router.get(
    "/{dialog_id}",
    status_code=status.HTTP_200_OK,
    response_model=list[MessageOut] | None,
    dependencies=[Depends(get_db)],
)
async def get_dialog(
    dialog_id: str,
    cred: HTTPAuthorizationCredentials = Security(security),
) -> list[MessageOut] | None:
    try:
        did = int(dialog_id)
        if auth_service.decode_token(cred.credentials):
            return message_service.get_messages(did)
        return None
    except ValueError:
        raise HTTPException(400, "ID param it's not number")


@message_router.delete(
    "/{dialog_id}",
    status_code=status.HTTP_200_OK,
    response_model=list[MessageOut] | None,
    dependencies=[Depends(get_db)],
)
async def delete_history(
    dialog_id: str,
    cred: HTTPAuthorizationCredentials = Security(security),
) -> list[MessageOut] | None:
    try:
        did = int(dialog_id)
        if auth_service.decode_token(cred.credentials):
            return message_service.delete_history(did)
        return None
    except ValueError:
        raise HTTPException(400, "ID param it's not number")


@message_router.websocket(
    "/ws/{user_id}",
    dependencies=[Depends(get_db)],
)
async def websocket(websocket: WebSocket, user_id: int):
    await message_service.websocket(websocket, user_id)
