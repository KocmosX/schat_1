from fastapi import APIRouter, Depends, HTTPException, Security, WebSocket, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from schemas.message import MessageOut
from services.message_service import MessageService
from services.auth_service import AuthService
from models import database

message_router = APIRouter()  # Создание роутера API

security = HTTPBearer()  # Инициализация HTTPBearer для аутентификации

auth_service = AuthService()  # Инициализация сервиса аутентификации
message_service = MessageService()  # Инициализация сервиса сообщений

def get_db():  # Функция для получения доступа к базе данных
    try:
        database.connect()  # Устанавливаем соединение с базой данных
    finally:
        if not database.is_closed():  # Проверяем не закрыта ли база данных
            database.close()  # Закрываем соединение

@message_router.get(
    "/{dialog_id}",
    status_code=status.HTTP_200_OK,
    response_model=list[MessageOut] | None,
    dependencies=[Depends(get_db)],
)
async def get_dialog(
    dialog_id: str,
    cred: HTTPAuthorizationCredentials = Security(security),
) -> list[MessageOut] | None:
    try:
        did = int(dialog_id)  # Преобразование строки dialog_id в целое число
        if auth_service.decode_token(cred.credentials):  # Проверка валидности токена аутентификации
            return message_service.get_messages(did)  # Возвращает список сообщений
        return None
    except ValueError:
        raise HTTPException(400, "ID param it's not number")  # Генерируем исключение при некорректном dialog_id

@message_router.delete(
    "/{dialog_id}",
    status_code=status.HTTP_200_OK,
    response_model=list[MessageOut] | None,
    dependencies=[Depends(get_db)],
)
async def delete_history(
    dialog_id: str,
    cred: HTTPAuthorizationCredentials = Security(security),
) -> list[MessageOut] | None:
    try:
        did = int(dialog_id)  # Преобразование строки dialog_id в целое число
        if auth_service.decode_token(cred.credentials):  # Проверка валидности токена аутентификации
            return message_service.delete_history(did)  # Удаляет историю сообщений
        return None
    except ValueError:
        raise HTTPException(400, "ID param it's not number")  # Генерируем исключение при некорректном dialog_id

@message_router.websocket(
    "/ws/{user_id}",
    dependencies=[Depends(get_db)],
)
async def websocket(websocket: WebSocket, user_id: int):
    await message_service.websocket(websocket, user_id)  # Обрабатывает веб-сокет сообщения между клиентом и сервером