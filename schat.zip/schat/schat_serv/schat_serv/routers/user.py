# Импорт необходимых модулей и классов
from fastapi import APIRouter, Depends, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from schemas.user import UserOut
from services.auth_service import AuthService
from services.user_service import UserService
from models import database

# Создание экземпляра роутера APIRouter
user_route = APIRouter()

# Создание экземпляра HTTPBearer для аутентификации
security = HTTPBearer()

# Создание экземпляра сервиса аутентификации (AuthService)
auth_service = AuthService()

# Создание экземпляра сервиса пользователя (UserService)
user_service = UserService()

# Определение функции для подключения к базе данных
def get_db():
    try:
        # Подключение к базе данных
        database.connect()
    finally:
        if not database.is_closed():
            # Закрытие соединения с базой данных
            database.close()

# Определение маршрута для получения списка пользователей
@user_route.get(
    "/",
    status_code=status.HTTP_200_OK,
    response_model=list[UserOut] | None,
    dependencies=[Depends(get_db)],
)
async def users(
    cred: HTTPAuthorizationCredentials = Security(security),
) -> list[UserOut] | None:
    # Расшифровка токена с использованием сервиса аутентификации
    if auth_service.decode_token(cred.credentials):
        # Получение списка пользователей с помощью сервиса пользователя
        return user_service.get_users()
    return None

# Определение маршрута для получения информации о текущем пользователе
@user_route.get(
    "/self",
    status_code=status.HTTP_200_OK,
    response_model=UserOut | None,
    dependencies=[Depends(get_db)],
)
async def self(
    cred: HTTPAuthorizationCredentials = Security(security),
) -> UserOut | None:
    # Расшифровка токена с использованием сервиса аутентификации
    if auth_service.decode_token(cred.credentials):
        # Извлечение идентификатора пользователя из расшифрованного токена
        user_id = auth_service.decode_token(cred.credentials)["id"]
        # Получение информации о самом пользователе с помощью сервиса пользователя
        return user_service.get_user_self(user_id)
    return None