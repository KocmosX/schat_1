from pydantic import BaseModel

from schemas.user import UserOut


class DialogOut(BaseModel): #Здесь импортируется класс UserOut из модуля schemas.user. В файле schemas.user определена модель данных для пользователя.
    id: int # поле типа int, представляющее идентификатор диалога.
    first_user: UserOut #поле типа UserOut, представляющее информацию о первом пользователе.
    second_user: UserOut #поле типа UserOut, представляющее информацию о втором пользователе.
