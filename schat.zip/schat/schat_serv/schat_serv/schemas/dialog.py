from pydantic import BaseModel

from schemas.user import UserOut


class DialogOut(BaseModel):
    id: int
    first_user: UserOut
    second_user: UserOut
