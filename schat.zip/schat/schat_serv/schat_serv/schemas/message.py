from datetime import datetime

from pydantic import BaseModel

from schemas.user import UserOut


class MessageOut(BaseModel):
    sender_id: int
    content: str
    created_at: datetime
