from datetime import datetime

from pydantic import BaseModel

from schemas.user import UserOut  # Импортируем модель UserOut из модуля schemas.user


class MessageOut(BaseModel):  # Определяем класс MessageOut, наследуемый от BaseModel
    sender_id: int  # Поле sender_id типа int
    content: str  # Поле content типа str
    created_at: datetime  # Поле created_at типа datetime
