import os
from typing import TypedDict
from dotenv import load_dotenv

import jwt
from fastapi import HTTPException
from passlib.context import CryptContext

from datetime import datetime, timedelta
from models.user import User
from schemas.token import Tokens
from services.user_service import UserService

load_dotenv()

# Определение типа словаря для полезной нагрузки токена
class Payload(TypedDict):
    id: int
    username: str


class AuthService:
    # Создание экземпляра хешера bcrypt для хэширования паролей
    _hasher_bcrypt = CryptContext(schemes=["bcrypt"])
    # Создание экземпляра хешера sha256 для хэширования токенов
    _hasher_sha256 = CryptContext(schemes=["sha256_crypt"])
    # Получение секретного ключа из переменных окружения
    _secret = os.getenv("JWT_SECRET") or ""
    # Создание экземпляра сервиса пользователей
    _user_service = UserService()

    def signup(self, dto) -> Tokens:
        # Валидация данных пользователя
        if (
            dto.email == ""
            or dto.nickname == ""
            or dto.first_name == ""
            or dto.last_name == ""
            or dto.password == ""
        ):
            raise HTTPException(400, "Some fields are empty")
        
        # Проверка наличия пользователя с таким же email
        if self._user_service.get_user_by_email(dto.email):
            raise HTTPException(400, "Email already exist")
        
        # Проверка наличия пользователя с таким же ником
        if self._user_service.get_user_by_nickname(dto.nickname):
            raise HTTPException(400, "Nickname already exist")
        
        # Создание нового пользователя
        new_user = self._user_service.create_user(
            dto, self._get_password_hash(dto.password)
        )
        
        # Генерация токенов доступа и обновления
        access_token = self._encode_token(new_user.id, str(new_user.email))
        refresh_token = self._encode_refresh_token(new_user.id, str(new_user.email))
        
        # Обновление refresh-токена у пользователя
        self._update_user_refresh_token(new_user, refresh_token)
        
        # Возврат сгенерированных токенов
        return Tokens(access_token=access_token, refresh_token=refresh_token)

    def signin(self, dto) -> Tokens:
        # Поиск пользователя по email или никнейму
        user_on_email = self._user_service.get_user_by_email(dto.login)
        user_on_nickname = self._user_service.get_user_by_nickname(dto.login)
        
        # Проверка наличия пользователя
        user = user_on_email or user_on_nickname
        if not user:
            raise HTTPException(400, "Invalid login")
        
        # Проверка правильности введенного пароля
        if not self._verify_password(dto.password, str(user.password_hash)):
            raise HTTPException(400, "Invalid password")
        
        # Генерация токенов доступа и обновления
        access_token = self._encode_token(user.id, str(user.email))
        refresh_token = self._encode_refresh_token(user.id, str(user.email))
        
        # Обновление refresh-токена у пользователя
        self._update_user_refresh_token(user, refresh_token)
        
        # Возврат сгенерированных токенов
        return Tokens(access_token=access_token, refresh_token=refresh_token)

    def refresh_tokens(self, refresh_token: str) -> Tokens:
        # Проверка наличия пользователя по email, указанному в токене
        user = self._user_service.get_user_by_email(
            self._decode_refresh_token(refresh_token)["username"]
        )
        
        # Проверка наличия пользователя
        if not user:
            raise HTTPException(404, "User not found")
        
        # Проверка валидности refresh-токена
        if user.token and not self._verify_tokens(refresh_token, str(user.token)):
            self._update_user_refresh_token(user, None)
            raise HTTPException(401, "Invalid refresh token")
        
        # Обновление токена доступа и генерация нового refresh-токена
        access_token = self._refresh_token(refresh_token)
        refresh_token = self._encode_refresh_token(user.id, str(user.email))
        
        # Обновление refresh-токена у пользователя
        self._update_user_refresh_token(user, refresh_token)
        
        # Возврат обновленных токенов
        return Tokens(access_token=access_token, refresh_token=refresh_token)

    def logout(self, token):
        # Получение пользователя по идентификатору, полученному из токена
        user = self._user_service.get_user_by_id(self.decode_token(token)["id"])
        if user:
            # Удаление refresh-токена у пользователя
            self._update_user_refresh_token(user, None)

    def _get_password_hash(self, password: str) -> str:
        # Хэширование пароля с использованием хешера sha256
        return self._hasher_sha256.hash(password)

    def _get_token_hash(self, token: str) -> str:
        # Хэширование токена с использованием хешера bcrypt
        return self._hasher_bcrypt.hash(token)

    def _verify_password(self, password: str, encoded_password: str) -> bool:
        # Проверка правильности пароля с использованием хешера sha256
        return self._hasher_sha256.verify(password, encoded_password)

    def _verify_tokens(self, token: str, encoded_token: str) -> bool:
        # Проверка правильности токенов с использованием хешера bcrypt
        return self._hasher_bcrypt.verify(token, encoded_token)

    def _encode_token(self, user_id: int, username: str) -> str:
        # Генерация токена с помощью библиотеки JWT
        payload = {
            "exp": datetime.utcnow() + timedelta(days=0, minutes=20),
            "iat": datetime.utcnow(),
            "scope": "access_token",
            "sub": user_id,
            "username": username,
        }
        return jwt.encode(payload, self._secret, algorithm="HS256")

    def decode_token(self, token: str) -> Payload:
        # Расшифровка токена и проверка его валидности
        try:
            payload = jwt.decode(token, self._secret, algorithms=["HS256"])

            if payload["scope"] == "access_token":
                return {"id": payload["sub"], "username": payload["username"]}
            raise HTTPException(
                status_code=401, detail="Scope for the token is invalid"
            )

        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token expired")

        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid token")

    def _decode_refresh_token(self, token: str) -> Payload:
        # Расшифровка refresh-токена и проверка его валидности
        try:
            payload = jwt.decode(token, self._secret, algorithms=["HS256"])

            if payload["scope"] == "refresh_token":
                return {"id": payload["sub"], "username": payload["username"]}
            raise HTTPException(
                status_code=401, detail="Scope for the token is invalid"
            )

        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token expired")

        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid token")

    def _encode_refresh_token(self, user_id: int, username: str) -> str:
        # Генерация refresh-токена с помощью библиотеки JWT
        payload = {
            "exp": datetime.utcnow() + timedelta(days=14, hours=0),
            "iat": datetime.utcnow(),
            "scope": "refresh_token",
            "sub": user_id,
            "username": username,
        }
        return jwt.encode(payload, self._secret, algorithm="HS256")

    def _refresh_token(self, refresh_token: str) -> str:
        # Обновление токена доступа на основе refresh-токена
        try:
            payload = jwt.decode(refresh_token, self._secret, algorithms=["HS256"])

            if payload["scope"] == "refresh_token":
                user_id = payload["sub"]
                username = payload["username"]
                new_token = self._encode_token(user_id, username)
                return new_token
            raise HTTPException(status_code=401, detail="Invalid scope for token")

        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Refresh token expired")

        except jwt.InvalidTokenError:
            raise HTTPException(status_code=401, detail="Invalid refresh token")

    def _update_user_refresh_token(self, user: User, refresh_token: str | None):
        user: User = User.get(User.id == user.id)
        if not user:
            raise HTTPException(404, "User not found")
        user.token = self._get_token_hash(refresh_token) if refresh_token else None
        # TODO: if neaded here to add last active
        user.save()
