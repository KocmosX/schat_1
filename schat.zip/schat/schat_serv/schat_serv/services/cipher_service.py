import os
from cryptography.fernet import Fernet

class CipherService:
    def __init__(self):
        # Получение ключа из системной переменной окружения CIPHER_KEY
        # Если переменная окружения не установлена, будет использован пустой ключ
        key = os.getenv("CIPHER_KEY") or ""
        # Создание экземпляра класса Fernet с использованием ключа
        self._fernet: Fernet = Fernet(key)

    def encrypt_message(self, message: str) -> str:
        # Шифрование сообщения с использованием Fernet и кодирование в строку
        return self._fernet.encrypt(message.encode()).decode()

    def decrypt_message(self, message: str) -> str:
        # Дешифрование сообщения с использованием Fernet и декодирование в строку
        return self._fernet.decrypt(message).decode()