import os
from cryptography.fernet import Fernet


class CipherService:
    def __init__(self):
        key = os.getenv("CIPHER_KEY") or ""
        self._fernet: Fernet = Fernet(key)

    def encrypt_message(self, message: str) -> str:
        return self._fernet.encrypt(message.encode()).decode()

    def decrypt_message(self, message: str) -> str:
        return self._fernet.decrypt(message).decode()
