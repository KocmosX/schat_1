from fastapi import WebSocket


class ConnectionManager:
    def __init__(self):
        self.active_connections = {}

    async def connect(self, websocket: WebSocket, user_id):
        if user_id in list(self.active_connections.keys()):
            await websocket.accept()
            await websocket.close(code=4000)
            return False

        await websocket.accept()
        self.active_connections[user_id] = websocket

        return True

    def disconnect(self, websocket: WebSocket):
        del self.active_connections[
            list(
                filter(
                    lambda x: self.active_connections[x] == websocket,
                    self.active_connections,
                )
            )[0]
        ]

    async def send_personal_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)

    async def send_user_message(self, message: str, user_id: int):
        websocket = self.active_connections[user_id]
        await websocket.send_text(message)

    async def broadcast(self, message: str):
        for _user_id, connection in self.active_connections.items():
            await connection.send_text(message)
