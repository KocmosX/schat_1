from fastapi import WebSocket

class ConnectionManager:
    def __init__(self):
        # Создание пустого словаря для хранения активных соединений
        self.active_connections = {}

    async def connect(self, websocket: WebSocket, user_id):
        # Метод для подключения нового WebSocket-соединения
        if user_id in list(self.active_connections.keys()):
            # Проверка, существует ли активное соединение для данного user_id
            await websocket.accept()
            await websocket.close(code=4000)
            return False

        await websocket.accept()
        # Принятие нового WebSocket-соединения
        self.active_connections[user_id] = websocket
        # Добавление соединения в словарь active_connections под ключом user_id

        return True

    def disconnect(self, websocket: WebSocket):
        # Метод для разрыва WebSocket-соединения
        del self.active_connections[
            list(
                filter(
                    lambda x: self.active_connections[x] == websocket,
                    self.active_connections,
                )
            )[0]
        ]
        # Удаление соединения из active_connections на основе переданного объекта websocket

    async def send_personal_message(self, message: str, websocket: WebSocket):
        # Метод для отправки персонального сообщения через WebSocket
        await websocket.send_text(message)
        # Отправка текстового сообщения message через указанное соединение websocket

    async def send_user_message(self, message: str, user_id: int):
        # Метод для отправки сообщения определенному пользователю с помощью WebSocket
        websocket = self.active_connections[user_id]
        # Получение соединения для указанного user_id из active_connections
        await websocket.send_text(message)
        # Отправка текстового сообщения message через полученное соединение

    async def broadcast(self, message: str):
        # Метод для отправки сообщения всем активным соединениям через WebSocket
        for _user_id, connection in self.active_connections.items():
            # Итерация по парам (user_id, connection) в active_connections
            await connection.send_text(message)
            # Отправка текстового сообщения message через каждое соединение