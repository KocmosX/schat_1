from fastapi import HTTPException  # Импорт класса HTTPException из модуля fastapi
from models.user import User  # Импорт класса User из модуля models.user
from schemas.dialog import DialogOut  # Импорт класса DialogOut из модуля schemas.dialog
from services.user_service import UserService  # Импорт класса UserService из модуля services.user_service
from models.dialog import Dialog  # Импорт класса Dialog из модуля models.dialog


class DialogService:
    _user_service = UserService()  # Создание экземпляра класса UserService и присваивание его атрибуту _user_service

    def get_dialogs(self, user_id: int) -> list[DialogOut]:
        print(user_id)  # Вывод значения переменной user_id в консоль

        dialogs = Dialog.select()  # Выбор всех записей из таблицы Dialog

        dialogs_out = []  # Создание пустого списка
        for dialog in dialogs:  # Итерация по каждому элементу dialogs
            if dialog.first_user_id == user_id or dialog.second_user_id == user_id:  # Проверка, является ли пользователь участником диалога
                dialogs_out.append(self.get_dialog_out(dialog))  # Добавление представления диалога в список dialogs_out

        return dialogs_out  # Возврат списка dialogs_out

    def get_dialog(self, dialog_id: int) -> DialogOut | None:
        dialog = Dialog.get(Dialog.id == dialog_id)  # Получение диалога с указанным dialog_id

        if not dialog:  # Если диалог не найден
            raise HTTPException(404, "Dialog not found")  # Вызов исключения HTTPException с кодом 404

        return DialogOut(
            id=dialog.id,
            first_user=self._user_service.get_user_out(dialog.first_user),
            second_user=self._user_service.get_user_out(dialog.second_user),
        )  # Возврат объекта DialogOut, представляющего информацию о диалоге

    def create_dialog(
        self, first_user_id: int, second_user_id: int
    ) -> DialogOut | None:
        first_user = User.get(User.id == first_user_id)  # Получение пользователя с указанным first_user_id
        if not first_user:  # Если пользователь не найден
            raise HTTPException(404, "First user not found")  # Вызов исключения HTTPException с кодом 404

        second_user = User.get(User.id == second_user_id)  # Получение пользователя с указанным second_user_id
        if not second_user:  # Если пользователь не найден
            raise HTTPException(404, "Second user not found")  # Вызов исключения HTTPException с кодом 404

        self.get_dialog_out(
            Dialog.create(
                first_user=first_user,
                second_user=second_user,
            )
        )  # Создание нового диалога и вызов метода get_dialog_out для получения его представления

    def get_dialog_out(self, dialog: Dialog):
        return DialogOut(
            id=dialog.id,
            first_user=self._user_service.get_user_out(dialog.first_user),
            second_user=self._user_service.get_user_out(dialog.second_user),
        )  # Создание объекта DialogOut, представляющего информацию о диалоге