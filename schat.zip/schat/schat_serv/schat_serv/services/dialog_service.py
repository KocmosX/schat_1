from fastapi import HTTPException
from models.user import User
from schemas.dialog import DialogOut
from services.user_service import UserService
from models.dialog import Dialog


class DialogService:
    _user_service = UserService()

    def get_dialogs(self, user_id: int) -> list[DialogOut]:
        print(user_id)

        dialogs = Dialog.select()

        dialogs_out = []
        for dialog in dialogs:
            if dialog.first_user_id == user_id or dialog.second_user_id == user_id:
                dialogs_out.append(self.get_dialog_out(dialog))

        return dialogs_out

    def get_dialog(self, dialog_id: int) -> DialogOut | None:
        dialog = Dialog.get(Dialog.id == dialog_id)

        if not dialog:
            raise HTTPException(404, "Dialog not found")

        return DialogOut(
            id=dialog.id,
            first_user=self._user_service.get_user_out(dialog.first_user),
            second_user=self._user_service.get_user_out(dialog.second_user),
        )

    def create_dialog(
        self, first_user_id: int, second_user_id: int
    ) -> DialogOut | None:
        first_user = User.get(User.id == first_user_id)
        if not first_user:
            raise HTTPException(404, "Frist user not found")

        second_user = User.get(User.id == second_user_id)
        if not second_user:
            raise HTTPException(404, "Second user not found")

        self.get_dialog_out(
            Dialog.create(
                first_user=first_user,
                second_user=second_user,
            )
        )

    def get_dialog_out(self, dialog: Dialog):
        return DialogOut(
            id=dialog.id,
            first_user=self._user_service.get_user_out(dialog.first_user),
            second_user=self._user_service.get_user_out(dialog.second_user),
        )
