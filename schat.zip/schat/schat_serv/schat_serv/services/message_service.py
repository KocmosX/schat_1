import json  # Импорт модуля json для работы с JSON
from fastapi import WebSocket, WebSocketDisconnect  # Импорт классов WebSocket и WebSocketDisconnect из модуля fastapi
from models.message import Message  # Импорт класса Message из модуля models.message
from models.dialog import Dialog  # Импорт класса Dialog из модуля models.dialog
from services.cipher_service import CipherService  # Импорт класса CipherService из модуля services.cipher_service
from services.connection_manager import ConnectionManager  # Импорт класса ConnectionManager из модуля services.connection_manager
from services.user_service import UserService  # Импорт класса UserService из модуля services.user_service
from schemas.message import MessageOut  # Импорт класса MessageOut из модуля schemas.message
from models.dialog_message import DialogMessage  # Импорт класса DialogMessage из модуля models.dialog_message
from datetime import datetime  # Импорт класса datetime из модуля datetime


class MessageService:
    manager = ConnectionManager()  # Создание экземпляра класса ConnectionManager и присваивание его атрибуту manager
    _user_service = UserService()  # Создание экземпляра класса UserService и присваивание его атрибуту _user_service
    keys = ["sender_id", "reciver_id", "content"]  # Задание списка ключей keys
    _cipher_service = CipherService()  # Создание экземпляра класса CipherService и присваивание его атрибуту _cipher_service

    def get_messages(self, dialog_id: int) -> list[MessageOut]:
        out = []  # Создание пустого списка
        # Выбор всех сообщений в диалоге с указанным dialog_id, присоединение таблицы Message и сортировка по времени создания
        messages = DialogMessage.select().where(DialogMessage.dialog_id == dialog_id).join(Message).order_by(DialogMessage.message.created_at)
        for message in messages:  # Итерация по каждому сообщению
            out.append(self.get_message_out(message.message))  # Добавление представления сообщения в список out
        return out  # Возврат списка out

    def get_message_out(self, message: Message) -> MessageOut:
        return MessageOut(
            sender_id=message.sender.id,
            content=self._cipher_service.decrypt_message(str(message.content)),  # Расшифровка содержимого сообщения
            created_at=message.created_at,
        )  # Создание объекта MessageOut, представляющего информацию о сообщении

    def delete_history(self, chat_id):
        dialog_messages = DialogMessage.select()  # Выбор всех записей из таблицы DialogMessage

        for dialog_message in dialog_messages:  # Итерация по каждой записи
            if dialog_message.dialog.id == chat_id:  # Проверка, принадлежит ли запись указанному chat_id
                q = DialogMessage.delete().where(DialogMessage.id == dialog_message.id)  # Удаление записи из таблицы DialogMessage
                q.execute()
                q = Message.delete().where(Message.id == dialog_message.message.id)  # Удаление связанного сообщения из таблицы Message
                q.execute()

        q = Dialog.delete().where(Dialog.id == chat_id)  # Удаление диалога с указанным chat_id
        q.execute()

    def new_message(self, data) -> Message:
        sender_id = data["sender_id"]  # Получение sender_id из данных
        reciver_id = data["reciver_id"]  # Получение reciver_id из данных
        content = data["content"]  # Получение content из данных

        sender_user = self._user_service.get_user_by_id(sender_id)  # Получение пользователя по указанному sender_id
        message = Message.create(
            sender=sender_user, content=self._cipher_service.encrypt_message(content), created_at=datetime.now()
        )  # Создание нового сообщения, зашифрованного содержимого и указанного времени создания

        dialog = None
        # FIXME: when peewee developers would be middle level
        for d in Dialog.select():  # Итерация по каждому диалогу
            fi = d.first_user_id
            si = d.second_user_id
            if (sender_id == fi or sender_id == si) and (
                reciver_id == fi or reciver_id == si
            ):
                dialog = d
                break

        if not dialog:  # Если диалог не найден
            reciver_user = self._user_service.get_user_by_id(reciver_id)  # Получение пользователя по указанному reciver_id

            dialog = Dialog.create(
                first_user=sender_user,
                second_user=reciver_user,
            )  # Создание нового диалога между отправителем и получателем

        DialogMessage.create(
            dialog=dialog,
            message=message,
        )  # Создание связи между диалогом и сообщением

        return message  # Возврат созданного сообщения

    async def websocket(self, websocket: WebSocket, user_id: int):
        if await self.manager.connect(websocket, int(user_id)) == False:  # Подключение websocket к менеджеру соединений
            return

        try:
            while True:
                rec = await websocket.receive_text()  # Получение текстового сообщения от websocket
                data: dict = json.loads(rec)  # Преобразование текстового сообщения в словарь

                if self.keys == list(data.keys()):  # Проверка, что все ключи из self.keys присутствуют в данных
                    message: Message = self.new_message(data)  # Создание нового сообщения на основе данных
                else:
                    print("JSON is invalid")
                    continue

                await self.manager.broadcast(f"{self.get_message_out(message).json()}")  # Рассылка представления сообщения всем подключенным клиентам

        except WebSocketDisconnect:  # Если websocket отключается
            self.manager.disconnect(websocket)  # Отключение websocket от менеджера соединений