import json
from fastapi import WebSocket, WebSocketDisconnect
from models.message import Message
from models.dialog import Dialog
from services.cipher_service import CipherService
from services.connection_manager import ConnectionManager
from services.user_service import UserService
from schemas.message import MessageOut
from models.dialog_message import DialogMessage
from datetime import datetime


class MessageService:
    manager = ConnectionManager()
    _user_service = UserService()
    keys = ["sender_id", "reciver_id", "content"]
    _cipher_service = CipherService()

    def get_messages(self, dialog_id: int) -> list[MessageOut]:
        out = []
        messages = DialogMessage.select().where(DialogMessage.dialog_id == dialog_id).join(Message).order_by(DialogMessage.message.created_at)
        for message in messages:
            out.append(self.get_message_out(message.message))
        return out

    def get_message_out(self, message: Message) -> MessageOut:
        return MessageOut(
            sender_id=message.sender.id,
            content=self._cipher_service.decrypt_message(str(message.content)),
            created_at=message.created_at,
        )

    def delete_history(self, chat_id):
        dialog_messages = DialogMessage.select()

        for dialog_message in dialog_messages:
            if dialog_message.dialog.id == chat_id:
                q = DialogMessage.delete().where(DialogMessage.id == dialog_message.id)
                q.execute()
                q = Message.delete().where(Message.id == dialog_message.message.id)
                q.execute()

        q = Dialog.delete().where(Dialog.id == chat_id)
        q.execute()

    def new_message(self, data) -> Message:
        sender_id = data["sender_id"]
        reciver_id = data["reciver_id"]
        content = data["content"]

        sender_user = self._user_service.get_user_by_id(sender_id)
        message = Message.create(
            sender=sender_user, content=self._cipher_service.encrypt_message(content), created_at=datetime.now()
        )

        dialog = None
        # FIXME: when peewee developers would be middle level
        for d in Dialog.select():
            fi = d.first_user_id
            si = d.second_user_id
            if (sender_id == fi or sender_id == si) and (
                reciver_id == fi or reciver_id == si
            ):
                dialog = d
                break

        if not dialog:
            reciver_user = self._user_service.get_user_by_id(reciver_id)

            dialog = Dialog.create(
                first_user=sender_user,
                second_user=reciver_user,
            )

        DialogMessage.create(
            dialog=dialog,
            message=message,
        )

        return message

    async def websocket(self, websocket: WebSocket, user_id: int):
        if await self.manager.connect(websocket, int(user_id)) == False:
            return

        try:
            while True:
                rec = await websocket.receive_text()
                data: dict = json.loads(rec)

                if self.keys == list(data.keys()):
                    message: Message = self.new_message(data)
                else:
                    print("JSON is invalid")
                    continue

                await self.manager.broadcast(f"{self.get_message_out(message).json()}")

        except WebSocketDisconnect:
            self.manager.disconnect(websocket)
