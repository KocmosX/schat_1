from fastapi import HTTPException
from schemas.user import UserOut, UserSignUp
from models.user import User
import peewee


class UserService:
    def get_users(self) -> list[UserOut]:
        # Получение списка всех пользователей
        users_out = []
        for user in User.select():
            users_out.append(self.get_user_out(user))
        return users_out

    def get_user_by_email(self, email: str) -> User | None:
        # Получение пользователя по электронной почте
        try:
            return User.get(User.email == email)
        except peewee.DoesNotExist:
            return None

    def get_user_by_nickname(self, nickname: str) -> User | None:
        # Получение пользователя по псевдониму (никнейму)
        try:
            return User.get(User.nickname == nickname)
        except peewee.DoesNotExist:
            return None

    def get_user_by_id(self, id: int) -> User | None:
        # Получение пользователя по идентификатору
        try:
            return User.get(User.id == id)
        except peewee.DoesNotExist:
            return None

    def create_user(self, dto: UserSignUp, encoded_password: str) -> User:
        # Создание нового пользователя
        return User.create(
            first_name=dto.first_name,
            last_name=dto.last_name,
            email=dto.email,
            nickname=dto.nickname,
            password_hash=encoded_password,
        )

    def get_user_self(self, id) -> UserOut | None:
        # Получение информации о текущем пользователе
        user = self.get_user_by_id(id)

        if user:
            return self.get_user_out(user)

        # Если пользователь не найден, возбуждается исключение
        raise HTTPException(404, "Self user not found")

    def get_user_out(self, user: User) -> UserOut:
        # Преобразование объекта пользователя в объект UserOut
        return UserOut(
            id=int(user.id),
            first_name=str(user.first_name),
            last_name=str(user.last_name),
            email=str(user.email),
            nickname=str(user.nickname),
        )